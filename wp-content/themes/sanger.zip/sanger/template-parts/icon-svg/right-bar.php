<a class="elementor-icon" href="#panel-bar">
    <svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21">
        <g id="Right_Bar" data-name="Right Bar" transform="translate(-2124 -2665)">
            <g id="Ellipse_362" data-name="Ellipse 362" transform="translate(2124 2665)" fill="none" stroke-width="1.5">
                <circle cx="2.5" cy="2.5" r="2.5" stroke="none"></circle>
                <circle cx="2.5" cy="2.5" r="1.75" fill="none"></circle>
            </g>
            <g id="Ellipse_363" data-name="Ellipse 363" transform="translate(2132 2665)" fill="none" stroke-width="1.5">
                <circle cx="2.5" cy="2.5" r="2.5" stroke="none"></circle>
                <circle cx="2.5" cy="2.5" r="1.75" fill="none"></circle>
            </g>
            <g id="Ellipse_364" data-name="Ellipse 364" transform="translate(2140 2665)" fill="none" stroke-width="1.5">
                <circle cx="2.5" cy="2.5" r="2.5" stroke="none"></circle>
                <circle cx="2.5" cy="2.5" r="1.75" fill="none"></circle>
            </g>
            <g id="Ellipse_365" data-name="Ellipse 365" transform="translate(2124 2673)" fill="none" stroke-width="1.5">
                <circle cx="2.5" cy="2.5" r="2.5" stroke="none"></circle>
                <circle cx="2.5" cy="2.5" r="1.75" fill="none"></circle>
            </g>
            <g id="Ellipse_366" data-name="Ellipse 366" transform="translate(2132 2673)" fill="none" stroke-width="1.5">
                <circle cx="2.5" cy="2.5" r="2.5" stroke="none"></circle>
                <circle cx="2.5" cy="2.5" r="1.75" fill="none"></circle>
            </g>
            <g id="Ellipse_367" data-name="Ellipse 367" transform="translate(2140 2673)" fill="none" stroke-width="1.5">
                <circle cx="2.5" cy="2.5" r="2.5" stroke="none"></circle>
                <circle cx="2.5" cy="2.5" r="1.75" fill="none"></circle>
            </g>
            <g id="Ellipse_368" data-name="Ellipse 368" transform="translate(2124 2681)" fill="none" stroke-width="1.5">
                <circle cx="2.5" cy="2.5" r="2.5" stroke="none"></circle>
                <circle cx="2.5" cy="2.5" r="1.75" fill="none"></circle>
            </g>
            <g id="Ellipse_369" data-name="Ellipse 369" transform="translate(2132 2681)" fill="none" stroke-width="1.5">
                <circle cx="2.5" cy="2.5" r="2.5" stroke="none"></circle>
                <circle cx="2.5" cy="2.5" r="1.75" fill="none"></circle>
            </g>
            <g id="Ellipse_370" data-name="Ellipse 370" transform="translate(2140 2681)" fill="none" stroke-width="1.5">
                <circle cx="2.5" cy="2.5" r="2.5" stroke="none"></circle>
                <circle cx="2.5" cy="2.5" r="1.75" fill="none"></circle>
            </g>
        </g>
    </svg> </a>