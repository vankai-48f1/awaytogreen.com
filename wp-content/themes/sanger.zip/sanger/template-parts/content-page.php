<!-- Title -->
<!--<h1 class="mt-4">< ?php the_title() ?></h1>-->
<!-- Date/Time -->
<!--<p>Posted on < ?php echo get_the_date() ?></p>-->

<!--<hr>-->

<!-- Post Content -->
<?php the_content() ?>
