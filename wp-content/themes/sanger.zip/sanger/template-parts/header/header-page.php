<div class="page-header">
    <div class="container">
        <div class="page-header__inner mtext-center">
            <h1 class="page-header__title font-secondary-medium-02"><?php echo is_category() ? single_cat_title() : get_the_title(); ?></h1>
            <div class="page-header__down"><span class="page-header__down-icon icon-down-open"></span></div>
        </div>
    </div>
</div>