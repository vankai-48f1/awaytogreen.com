<div class="header-partial">
    <h2 class="font-primary-bold-40"><span><?php echo $args['title'] ?></span><span class="header-partial__icon"></span></h2>
</div>